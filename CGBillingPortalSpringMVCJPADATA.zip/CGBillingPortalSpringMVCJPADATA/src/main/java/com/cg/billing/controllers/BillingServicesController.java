package com.cg.billing.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
public class BillingServicesController {
	@Autowired
	BillingServices billingServices;
	
	@RequestMapping("/CustomerRegistration")
	public ModelAndView registerCustomer(@Valid@ModelAttribute Customer customer,BindingResult result) {
		if(result.hasErrors()) return new ModelAndView("customerRegistrationPage");
		customer = billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("customerRegistrationSuccessPage","customer",customer);
	}
	
	@RequestMapping("/customerDetails")
	public ModelAndView getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		Customer customer = billingServices.getCustomerDetails(customerID);
		return new ModelAndView("findCustomerDetailsPage","customer",customer);
	}
	

	@RequestMapping("/allCustomerDetails")
	public ModelAndView getAllCustomerDetails(){
		return new ModelAndView("findAllCustomerDetailsPage","customers",billingServices.getAllCustomerDetails());
	}
	
	@RequestMapping("/postpaidAccount")
	public ModelAndView openPostpaidAccount(@RequestParam int customerID,@RequestParam int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		PostpaidAccount postpaidAccount = billingServices.openPostpaidMobileAccount(customerID,planID);
		return new ModelAndView("postpaidAccountRegistrationSuccessPage","account",postpaidAccount);
	}
	

	
}

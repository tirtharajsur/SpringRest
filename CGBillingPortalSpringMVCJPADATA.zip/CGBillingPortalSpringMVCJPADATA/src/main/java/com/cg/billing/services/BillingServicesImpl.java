package com.cg.billing.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostpaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private CustomerDAO customerData;
	@Autowired
	private BillDAO billData;
	@Autowired
	private PlanDAO planData;
	@Autowired
	private PostpaidAccountDAO accountData;
	/*
	 * @Autowired private static BillingServices billingServices;
	 */
	public Map<Integer, Bill> bills = new HashMap<Integer, Bill>();

	/*
	 * public static BillingServices getInstance() { if (billingServices == null)
	 * billingServices = new BillingServicesImpl(); return billingServices; }
	 */

	@Override
	public List<Plan> getPlanAllDetails() {
		List<Plan> plans = planData.findAll();
		return plans;
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {

		return customerData.save(customer);
	}

	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		Customer customer = getCustomerDetails(customerID);
		Plan plan = planData.findById(planID)
				.orElseThrow(() -> new PlanDetailsNotFoundException("Plan Details Not Found!!!"));
		return accountData.save(new PostpaidAccount(plan, customer));
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {

		/*
		 * double amount = 0; Customer customer = getCustomerDetails(customerID);
		 * 
		 * Bill bill = new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls,
		 * internetDataUsageUnits, billMonth); Plan plan = new Plan(0.30f, 1f, 0.10f,
		 * 1f, 0.10f);
		 * 
		 * amount+=bill.getNoOfStdSMS()*plan.getLocalSMSRate() +
		 * bill.getNoOfLocalSMS()*plan.getLocalSMSRate() +
		 * bill.getNoOfLocalCalls()*plan.getLocalCallRate()
		 * +bill.getNoOfStdCalls()*plan.getStdCallRate()
		 * +bill.getInternetDataUsageUnits()*plan.getInternetDataUsageRate();
		 * PostpaidAccount postpaidAccount = getPostPaidAccountDetails(customerID,
		 * mobileNo); List<Bill> postPaidBillList = new
		 * ArrayList<Bill>(postpaidAccount.getBills().values()); for (Bill bill :
		 * postPaidBillList) { amount += (noOfStdSMS * bill.getStdSMSAmount()) +
		 * (noOfLocalSMS * bill.getLocalSMSAmount()) + (noOfLocalCalls *
		 * bill.getLocalCallAmount()) + (noOfStdCalls * bill.getStdCallAmount()) +
		 * (internetDataUsageUnits * bill.getInternetDataUsageAmount());
		 * 
		 * 
		 * bill.setTotalBillAmount((float)amount); bills.put(bill.getBillID(), (Bill)
		 * bills); postpaidAccount.setBills((HashMap<Integer, Bill>) bills);
		 * 
		 * return amount;
		 */
		float internetDataUsageAmount=0,localCallAmount=0,stdCallAmount=0,localSMSAmount=0,stdSMSAmount=0,totalBillAmount=0,stateGST, centralGST;
		Customer customer= customerData.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		Map<Long, PostpaidAccount> postpaidMap=customer.getPostpaidAccounts();
		PostpaidAccount acc=postpaidMap.get(mobileNo);
		Plan p=acc.getPlan();
		if(internetDataUsageUnits-p.getFreeInternetDataUsageUnits()>0)
			internetDataUsageAmount=(internetDataUsageUnits-p.getFreeInternetDataUsageUnits())*p.getInternetDataUsageRate();
		
		if(noOfLocalCalls-p.getFreeLocalCalls()>0)
			localCallAmount=(noOfLocalCalls-p.getFreeLocalCalls())*p.getFreeLocalCalls();
		
		if(noOfStdCalls-p.getFreeStdCalls()>0)
			stdCallAmount=(noOfStdCalls-p.getFreeStdCalls())*p.getStdCallRate();
		
		if(noOfLocalSMS-p.getFreeLocalSMS()>0)
			localSMSAmount=(noOfLocalSMS-p.getFreeLocalSMS())*p.getFreeLocalSMS();
		
		if(noOfStdSMS-p.getFreeLocalSMS()>0)
			stdSMSAmount=(noOfStdSMS-p.getFreeStdSMS())*p.getFreeStdSMS();
		
		totalBillAmount=internetDataUsageAmount+localCallAmount+stdCallAmount+localSMSAmount+stdSMSAmount;
		stateGST=(float) (.09*totalBillAmount);
		centralGST=(float) (.09*totalBillAmount);
		totalBillAmount+=(stateGST+centralGST);
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, stateGST, centralGST);
		billData.save(bill);
		return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {

		Customer customer = customerData.findById(customerID)
				.orElseThrow(() -> new CustomerDetailsNotFoundException("Customer Details Not Found !!"));
		if (customer == null)
			throw new CustomerDetailsNotFoundException("Customer Not Found!!!");
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {

		return customerData.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount postpaidAccount = accountData.findById(mobileNo)
				.orElseThrow(() -> new PostpaidAccountNotFoundException("Postpaid Account not Found!!!"));
		if (postpaidAccount == null)
			throw new PostpaidAccountNotFoundException("Postpaid Account Not Found!!!");

		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {

		Customer customer = getCustomerDetails(customerID);

		return new ArrayList<PostpaidAccount>(customer.getPostpaidAccounts().values());
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		Bill bills = null;
		Customer customer = getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount = accountData.findById(mobileNo)
				.orElseThrow(() -> new PostpaidAccountNotFoundException("Postpaid Account not Found!!!"));
		if (postpaidAccount == null)
			throw new PostpaidAccountNotFoundException("This Postpaid Account does not Exist!!!");
		if (!billMonth.equalsIgnoreCase("January") || !billMonth.equalsIgnoreCase("February")
				|| !billMonth.equalsIgnoreCase("March") || !billMonth.equalsIgnoreCase("April")
				|| !billMonth.equalsIgnoreCase("May") || !billMonth.equalsIgnoreCase("June")
				|| !billMonth.equalsIgnoreCase("July") || !billMonth.equalsIgnoreCase("August")
				|| !billMonth.equalsIgnoreCase("September") || !billMonth.equalsIgnoreCase("October")
				|| !billMonth.equalsIgnoreCase("November") || !billMonth.equalsIgnoreCase("December"))
			throw new InvalidBillMonthException("Invalid month!!!!");

		List<Bill> billList = new ArrayList<Bill>(postpaidAccount.getBills().values());
		for (Bill bill : billList) {
			if (bill.getBillMonth().equals(billMonth))
				bills = bill;
			break;
		}
		return bills;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount = accountData.findById(mobileNo)
				.orElseThrow(() -> new PostpaidAccountNotFoundException("Postpaid Account not Found!!!"));
		if (customer == null)
			throw new CustomerDetailsNotFoundException("Customer Not Found!!!");
		if (postpaidAccount == null)
			throw new PostpaidAccountNotFoundException("This Postpaid Account does not Exist!!!");
		return new ArrayList<Bill>(postpaidAccount.getBills().values());
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		Customer customer = customerData.findById(customerID)
				.orElseThrow(() -> new CustomerDetailsNotFoundException("Customer Details Not Found !!"));
		PostpaidAccount postpaidAccount = accountData.findById(mobileNo)
				.orElseThrow(() -> new PostpaidAccountNotFoundException("Postpaid Account not Found!!!"));
		Plan plan = planData.findById(planID)
				.orElseThrow(() -> new PlanDetailsNotFoundException("Plan Details Not Found !!"));
		if (postpaidAccount.getPlan().equals(plan))
			planData.save(plan);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount = accountData.findById(mobileNo)
				.orElseThrow(() -> new PostpaidAccountNotFoundException("Postpaid Account not Found!!!"));
		if (postpaidAccount == null)
			throw new PostpaidAccountNotFoundException("This Postpaid Account does not Exist!!!");
		accountData.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		/* Customer customer = getCustomerDetails(customerID); */
		customerData.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {

		PostpaidAccount postpaidAccount = accountData.findById(mobileNo)
				.orElseThrow(() -> new PostpaidAccountNotFoundException("Postpaid Account not Found!!!"));
		if (postpaidAccount == null)
			throw new PostpaidAccountNotFoundException("This Postpaid Account does not Exist!!!");
		Customer customer = getCustomerDetails(customerID);
		if (customer == null)
			throw new CustomerDetailsNotFoundException("Customer Not Found!!!");
		Plan plan = postpaidAccount.getPlan();
		if (plan == null)
			throw new PlanDetailsNotFoundException("Sorry Plan not found!!");

		return plan;
	}

}

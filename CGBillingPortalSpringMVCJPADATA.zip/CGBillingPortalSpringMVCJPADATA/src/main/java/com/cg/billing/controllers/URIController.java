package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController {
	

	
	@RequestMapping(value= {"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/customerRegistration")
	public String getCustomerRegistrationPAge() {
		return "customerRegistrationPage";
	}
	
	@RequestMapping("/findCustomerDetails")
	public String getFindCustomerDetailsPage() {
		return "findCustomerDetailsPage";
	}
	
	@RequestMapping("/findAllCustomerDetails")
	public String getFindAllCustomerDetailsPage() {
		return "findAllCustomerDetailsPage";
	}
	
	@RequestMapping("/postpaidAccountRegistration")
	public String getPostpaidAccountRegistrationPage() {
		return "postpaidAccountRegistrationPage";
	}
	
	/*
	 * @RequestMapping("/findCustomerDetails"") public String
	 * getFindAssociateDetailsPage() { return "findCustomerDetails"Page"; }
	 * 
	 * @RequestMapping("/calculateNetSalary") public String
	 * getCalculateNetSalaryPage() { return "calculateNetSalaryPage"; }
	 * 
	 * @RequestMapping("/findAllAssociateDetails") public String
	 * getFindAllAssociateDetailsPage() { return "findAllAssociateDetailsPage"; }
	 */
	
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}

}

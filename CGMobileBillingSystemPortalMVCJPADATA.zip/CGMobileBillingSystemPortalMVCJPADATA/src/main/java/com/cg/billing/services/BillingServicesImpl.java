package com.cg.billing.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostpaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {

	@Autowired
	private PlanDAO planDao;
	@Autowired
	private CustomerDAO customerDao;
	@Autowired
	private BillDAO billDao;
	@Autowired
	private PostpaidAccountDAO postpaidAccountDao;
	public Map<Integer, Bill> bills = new HashMap<Integer, Bill>();

	@Override
	public List<Plan> getPlanAllDetails() {
		// TODO Auto-generated method stub
		return planDao.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		return customerDao.save(customer);
	}

	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub

		return postpaidAccountDao.save(new PostpaidAccount(planDao.findById(planID).orElseThrow(() -> new PlanDetailsNotFoundException("No plans found with ID : "+planID)), getCustomerDetails(customerID)));
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		// TODO Auto-generated method stub
		/*
		 * double amount = 0; Bill bill = new Bill(noOfLocalSMS, noOfStdSMS,
		 * noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth);
		 * 
		 * Plan plan = new Plan(1f, 1.5f, 0.8f, 1.2f,0.1f); plan = planDao.save(plan);
		 * PostpaidAccount postpaidAccount = getPostPaidAccountDetails(customerID,
		 * mobileNo);
		 * 
		 * amount += (bill.getNoOfLocalSMS()*plan.getLocalSMSRate()) +
		 * (bill.getNoOfStdSMS()*plan.getStdSMSRate()) +
		 * (bill.getNoOfLocalCalls()*plan.getLocalCallRate()) +
		 * (bill.getNoOfStdCalls()*plan.getStdCallRate())+
		 * (bill.getInternetDataUsageUnits()*plan.getInternetDataUsageRate());
		 * 
		 * bill.setTotalBillAmount((float) amount); bill = billDao.save(bill);
		 * 
		 * 
		 * bills.put(bill.getBillID(), bill); postpaidAccount.setBills(bills);
		 * 
		 * return amount;
		 */

		float internetDataUsageAmount=0,localCallAmount=0,stdCallAmount=0,localSMSAmount=0,stdSMSAmount=0,totalBillAmount=0,stateGST, centralGST;
		Customer customer= customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		Map<Long, PostpaidAccount> postpaidMap=customer.getPostpaidAccounts();
		PostpaidAccount acc=postpaidMap.get(mobileNo);
		Plan p=acc.getPlan();
		if(internetDataUsageUnits-p.getFreeInternetDataUsageUnits()>0)
			internetDataUsageAmount=(internetDataUsageUnits-p.getFreeInternetDataUsageUnits())*p.getInternetDataUsageRate();

		if(noOfLocalCalls-p.getFreeLocalCalls()>0)
			localCallAmount=(noOfLocalCalls-p.getFreeLocalCalls())*p.getFreeLocalCalls();

		if(noOfStdCalls-p.getFreeStdCalls()>0)
			stdCallAmount=(noOfStdCalls-p.getFreeStdCalls())*p.getStdCallRate();

		if(noOfLocalSMS-p.getFreeLocalSMS()>0)
			localSMSAmount=(noOfLocalSMS-p.getFreeLocalSMS())*p.getFreeLocalSMS();

		if(noOfStdSMS-p.getFreeLocalSMS()>0)
			stdSMSAmount=(noOfStdSMS-p.getFreeStdSMS())*p.getFreeStdSMS();

		totalBillAmount=internetDataUsageAmount+localCallAmount+stdCallAmount+localSMSAmount+stdSMSAmount;
		stateGST=(float) (.09*totalBillAmount);
		centralGST=(float) (.09*totalBillAmount);
		totalBillAmount+=(stateGST+centralGST);
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, stateGST, centralGST);
		billDao.save(bill);
		acc.getBills().put(bill.getBillID(), bill);
		bill.setPostpaidAccount(postpaidAccountDao.save(acc));
		
		billDao.save(bill);
		return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub

		return customerDao.findById(customerID).orElseThrow(() -> new CustomerDetailsNotFoundException("No customer found with ID : "+customerID));
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		return customerDao.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		// TODO Auto-generated method stub
		Customer customer = getCustomerDetails(customerID);
		return postpaidAccountDao.findById(mobileNo).orElseThrow(() -> (new PostpaidAccountNotFoundException("No such PP account found with mobileNo : "+mobileNo)));
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return new ArrayList<PostpaidAccount>(getCustomerDetails(customerID).getPostpaidAccounts().values());
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		// TODO Auto-generated method stub
		Bill b=null;
		PostpaidAccount postpaidAccount = getPostPaidAccountDetails(customerID, mobileNo);
		if(!billMonth.equalsIgnoreCase("January") || !billMonth.equalsIgnoreCase("February") || !billMonth.equalsIgnoreCase("March")
				|| !billMonth.equalsIgnoreCase("April") || !billMonth.equalsIgnoreCase("May") || !billMonth.equalsIgnoreCase("June")
				|| !billMonth.equalsIgnoreCase("July") || !billMonth.equalsIgnoreCase("August") || !billMonth.equalsIgnoreCase("September")
				|| !billMonth.equalsIgnoreCase("October") || !billMonth.equalsIgnoreCase("November") || !billMonth.equalsIgnoreCase("December"))
			throw new InvalidBillMonthException();


		List<Bill> billList = new ArrayList<Bill>(postpaidAccount.getBills().values()); 
		for (Bill bill : billList) {
			if(bill.getBillMonth().equals(billMonth)) 
			{ b = bill; break; } 
		}


		//generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return b;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return new ArrayList<Bill>(getPostPaidAccountDetails(customerID, mobileNo).getBills().values());
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		PostpaidAccount postpaidAccount = getPostPaidAccountDetails(customerID, mobileNo);
		Plan plan = planDao.findById(planID).orElseThrow(() -> new PlanDetailsNotFoundException("No plan found with plan ID : "+planID));
		planDao.save(plan);
		postpaidAccount.setPlan(plan);
		postpaidAccountDao.save(postpaidAccount);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		// TODO Auto-generated method stub
		PostpaidAccount postpaidAccount = getPostPaidAccountDetails(customerID, mobileNo);
		postpaidAccountDao.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		customerDao.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return getPostPaidAccountDetails(customerID, mobileNo).getPlan();
	}

}

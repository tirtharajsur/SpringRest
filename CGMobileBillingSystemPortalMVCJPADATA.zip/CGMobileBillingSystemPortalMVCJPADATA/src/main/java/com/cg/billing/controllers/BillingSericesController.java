package com.cg.billing.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
public class BillingSericesController {
	@Autowired
	BillingServices billingServices;
	
	@RequestMapping("/CustomerRegistration")
	public ModelAndView registerCustomer(@Valid@ModelAttribute Customer customer, BindingResult result) {
		if(result.hasErrors())
			return new ModelAndView("RegisterDetails");
		customer = billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("AccountRegisteredSuccessPage", "customer", customer);
	}
	
	@RequestMapping("/postpaidDetail")
	public ModelAndView openPostPaidAccountForCustomer(@RequestParam int customerID, int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		return new ModelAndView("postPaidSuccessPage", "postpaidAccount", billingServices.openPostpaidMobileAccount(customerID, planID));
	}
	
	@RequestMapping("/custDetails")
	public ModelAndView getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException  {
		return new ModelAndView("OneCustomerDetails", "customer", billingServices.getCustomerDetails(customerID));
	}
	
	@RequestMapping("/AllCustDetails")
	public ModelAndView getAllCustomerDetails() {
		return new ModelAndView("AllCustomerDetails", "customers", billingServices.getAllCustomerDetails());
	}

	@RequestMapping("/PPAccDetails")
	public ModelAndView getPPCustomerDetails(@RequestParam int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		return new ModelAndView("postpaidAccountDetails", "postpaidAccount", billingServices.getPostPaidAccountDetails(customerID, mobileNo));
	}
	

	@RequestMapping("/AllPPAccDetails")
	public ModelAndView getAllPPAccCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		return new ModelAndView("allPostpaidAccountDetailsPage", "postpaidAccounts", billingServices.getCustomerAllPostpaidAccountsDetails(customerID));
	}
	
	@RequestMapping("/AllPlanDetails")
	public ModelAndView getAllPlanDetails()  {
		return new ModelAndView("AllPlanDetailsPage", "plans", billingServices.getPlanAllDetails());
	}
	
	@RequestMapping("/MonthlyBillDetails")
	public ModelAndView generateMonthlyMobileBillDetails(@RequestParam int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException  {
		return new ModelAndView("MonthlyBillDetailsSuccessPage", "billAmount", billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits));
	}
	

	@RequestMapping("/billDetails")
	public ModelAndView getBillDetails(@RequestParam int customerID, long mobileNo, String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		return new ModelAndView("BillDetailsSuccessPage", "bill", billingServices.getMobileBillDetails(customerID, mobileNo, billMonth));
	}
	
	@RequestMapping("/AllBillDetails")
	public ModelAndView getAllBillDetails(@RequestParam int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		return new ModelAndView("AllBillDetailsSuccessPage", "bills", billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo));
	}

	@RequestMapping("/removeCustDet")
	public ModelAndView removeEntireCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException  {
		return new ModelAndView("CustomerDetailsRemovedSuccessPage", "status",billingServices.removeCustomerDetails(customerID));
	}
	
	@RequestMapping("/closePPAcc")
	public ModelAndView closeCustomerPPAccount(@RequestParam int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		return new ModelAndView("CustomerPPAccClosedSuccessPage", "status", billingServices.closeCustomerPostPaidAccount(customerID, mobileNo));
	}
	
	@RequestMapping("/changeCustomerPlan")
	public ModelAndView changeCustomerPlanDetails(@RequestParam int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		return new ModelAndView("CustomerPlanChangedSuccessPage", "status", billingServices.changePlan(customerID, mobileNo, planID));
	}
}
